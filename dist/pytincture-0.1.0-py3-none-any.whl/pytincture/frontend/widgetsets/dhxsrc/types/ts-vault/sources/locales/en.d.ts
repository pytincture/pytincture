declare const locale: {
    dragAndDrop: string;
    or: string;
    browse: string;
    filesOrFoldersHere: string;
    cancel: string;
    clearAll: string;
    clear: string;
    add: string;
    upload: string;
    download: string;
    error: string;
    byte: string;
    kilobyte: string;
    megabyte: string;
    gigabyte: string;
};
export default locale;
