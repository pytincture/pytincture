export declare const shadow: () => any;
export declare const dropShadow: () => any;
