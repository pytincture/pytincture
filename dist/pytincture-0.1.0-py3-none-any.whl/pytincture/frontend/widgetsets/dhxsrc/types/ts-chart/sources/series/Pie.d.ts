import { SvgElement } from "../types";
import NoScaleSeria from "./NoScaleSeria";
export default class Pie extends NoScaleSeria {
    paint(width: number, height: number): SvgElement;
}
