import { PointData } from "../types";
import Area from "./Area";
export default class SplineArea extends Area {
    protected _form(width: number, height: number, svg: any[], prev: PointData[]): object;
}
