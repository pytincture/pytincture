export declare function legendShape(form: any, item: any): any;
export declare function legendTicks(form: any, item: any): any[];
