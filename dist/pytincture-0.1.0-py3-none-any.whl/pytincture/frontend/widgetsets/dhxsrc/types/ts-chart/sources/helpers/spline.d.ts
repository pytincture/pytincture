import { PointData } from "../types";
export default function spline(initPoints: PointData[], link?: boolean): string;
