import { SvgElement } from "../types";
import NoScaleSeria from "./NoScaleSeria";
export default class Donut extends NoScaleSeria {
    paint(width: number, height: number): SvgElement;
}
