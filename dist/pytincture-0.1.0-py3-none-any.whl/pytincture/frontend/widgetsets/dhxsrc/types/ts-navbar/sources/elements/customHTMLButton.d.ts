export declare function customHTMLButton(item: any, widgetName?: string, asMenuItem?: boolean): any;
